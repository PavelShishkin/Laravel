<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
//Подключаю модели
use App\Models\Products;
use App\Models\Categories;
use App\Models\Types;
use App\Models\Groups;

use App\Http\Controllers\MailController;


class HomeController extends Controller
{
    public function index()
    { 
        return view("index");
    }
	
	public function register()
	{
		return view("register");
	}
	
    public function login()
    { 
        return view("login");
    }
   
    public function contact()
    { 
        return view("contact");
    }
    
    public function product($id)
    { 
        $products = Products::products_categor($id);
        return view("product",['products'=>$products]);
    }
    
    //------------------------------АДМИНКА---------------------------------------------
    public function inspection()
    {
		//Проверка входа пользователя
        if(empty($_SESSION['user_id']))
        {
            header('Location: 404');
        }
    }
    
    public function admin()
    { 
        $this->inspection(); 
        return view("admin.admin");
    }
    
    public function admin_exit()
    { 
		$this->inspection();
        unset($_SESSION['user_id']);
        session_destroy(); 
        return view("index");
    }
    
    public function admin_goods()
    {   
		$this->inspection();
    	return view("admin.goods");
    }
    
    public function admin_categories($id)
    { 
        $this->inspection();
        
        $categories = Categories::categories_type_id($id);
        $array = ['categories'      => $categories,
                  'categor_type_id' => $id];
      
        return view("admin.categories",$array);
    }
    
    public function admin_groups($type_id,$categor_id)
    { 
        $this->inspection();
        
        $groups = Groups::groups_categor_id($categor_id);
        $array = ['groups'     => $groups,
                  'categor_id' => $categor_id,
				  'type_id'    => $type_id];
     
        return view("admin.groups",$array);
    }
	
	public function admin_products($type_id,$categor_id,$group_id)
    { 
        $this->inspection();
        $products = Products::all_products_group_id($group_id);
   		$array = ['type_id'    => $type_id,
				  'categor_id' => $categor_id,
				  'group_id'   => $group_id,
				  'products'   => $products];
		
        return view("admin.products",$array);
    }
}
