<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Messages extends Model
{
    public static function add_message($name,$email,$message)
    {
        DB::insert("INSERT INTO `shop_messages` 
                            (`message_name`,`message_email`,`message_text`) 
                    VALUES
                            ('".$name."','".$email."','".$message."')");
    }
}
